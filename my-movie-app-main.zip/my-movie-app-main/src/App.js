import React, { useState, useEffect } from "react";
import "./App.css";

// Replace with your OMDb API key
const API_KEY = "e167fd75";

// Homepage categories
const categories = [
  { name: "All", query: "movie" },
  { name: "Action", query: "action" },
  { name: "Thriller", query: "thriller" },
  { name: "Romance", query: "romance" },
];

function App() {
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [categoryMovies, setCategoryMovies] = useState({});
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [favorites, setFavorites] = useState([]);
  const [playlist, setPlaylist] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
const fetchMovies = async (query) => {
  if (!query) return [];
  try {
    const res = await fetch(
      `https://www.omdbapi.com/?apikey=${API_KEY}&s=${query}`
    ); // <-- removed &type=movie to include series too
    const data = await res.json();
    if (data.Search) return data.Search;
    return [];
  } catch (err) {
    console.error(err);
    return [];
  }
};



  // Fetch homepage category movies
  useEffect(() => {
    const fetchCategories = async () => {
      const results = {};
      for (let cat of categories) {
        const movies = await fetchMovies(cat.query);
        results[cat.name] = movies;
      }
      setCategoryMovies(results);
    };
    fetchCategories();
  }, []);

  // Handle search
  const handleSearch = async () => {
    if (!searchTerm) return;
    const results = await fetchMovies(searchTerm);
    setSearchResults(results);
    setSelectedMovie(null);
  };

  // Fetch full movie details + recommendations
  const fetchMovieDetails = async (imdbID) => {
    try {
      const res = await fetch(
        `https://www.omdbapi.com/?apikey=${API_KEY}&i=${imdbID}&plot=full`
      );
      const data = await res.json();
      setSelectedMovie(data);

      // Fetch recommendations based on primary genre
      if (data.Genre) {
        const primaryGenre = data.Genre.split(",")[0].trim();
        const recs = await fetchMovies(primaryGenre);
        // Remove selected movie from recommendations
        setRecommendations(recs.filter((m) => m.imdbID !== imdbID));
      } else {
        setRecommendations([]);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Toggle favorite
  const toggleFavorite = (movie) => {
    if (favorites.some((fav) => fav.imdbID === movie.imdbID)) {
      setFavorites(favorites.filter((fav) => fav.imdbID !== movie.imdbID));
    } else {
      setFavorites([...favorites, movie]);
    }
  };

  // Toggle playlist
  const togglePlaylist = (movie) => {
    if (playlist.some((p) => p.imdbID === movie.imdbID)) {
      setPlaylist(playlist.filter((p) => p.imdbID !== movie.imdbID));
    } else {
      setPlaylist([...playlist, movie]);
    }
  };

  return (
    <div className="app">
      <h1>My Movie App</h1>

      {/* Search Bar */}
      <div className="search-bar">
        <input
          type="text"
          placeholder="Search movies or series..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSearch()}
        />
        <button onClick={handleSearch}>Search</button>
      </div>

      {/* Search Results */}
      {searchTerm && (
        <>
          <h2>Search Results for "{searchTerm}"</h2>
          <div className="movies">
            {searchResults.length > 0 ? (
              searchResults.map((movie) => (
                <div key={movie.imdbID} className="movie-card">
                  <img
                    src={
                      movie.Poster !== "N/A"
                        ? movie.Poster
                        : "https://via.placeholder.com/300x450?text=No+Poster"
                    }
                    alt={movie.Title}
                    onClick={() => fetchMovieDetails(movie.imdbID)}
                  />
                  <h4>{movie.Title}</h4>
                  <div className="card-actions">
                    <button onClick={() => toggleFavorite(movie)}>
                      {favorites.some((f) => f.imdbID === movie.imdbID)
                        ? "★"
                        : "☆"}
                    </button>
                    <button onClick={() => togglePlaylist(movie)}>▶</button>
                  </div>
                </div>
              ))
            ) : (
              <p>No results found.</p>
            )}
          </div>
        </>
      )}

      {/* Homepage Categories */}
      {!searchTerm &&
        Object.keys(categoryMovies).map((cat) => (
          <div key={cat}>
            <h2>{cat} Movies</h2>
            <div className="movies">
              {categoryMovies[cat].map((movie) => (
                <div key={movie.imdbID} className="movie-card">
                  <img
                    src={
                      movie.Poster !== "N/A"
                        ? movie.Poster
                        : "https://via.placeholder.com/300x450?text=No+Poster"
                    }
                    alt={movie.Title}
                    onClick={() => fetchMovieDetails(movie.imdbID)}
                  />
                  <h4>{movie.Title}</h4>
                  <div className="card-actions">
                    <button onClick={() => toggleFavorite(movie)}>
                      {favorites.some((f) => f.imdbID === movie.imdbID)
                        ? "★"
                        : "☆"}
                    </button>
                    <button onClick={() => togglePlaylist(movie)}>▶</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}

      {/* Movie Details Panel */}
      {selectedMovie && (
        <div className="movie-details">
          <img
            src={
              selectedMovie.Poster !== "N/A"
                ? selectedMovie.Poster
                : "https://via.placeholder.com/300x450?text=No+Poster"
            }
            alt={selectedMovie.Title}
          />
          <div className="details-text">
            <h2>{selectedMovie.Title}</h2>
            <p>
              <b>Plot:</b> {selectedMovie.Plot}
            </p>
            <p>
              <b>Actors:</b> {selectedMovie.Actors}
            </p>
            <p>
              <b>Director:</b> {selectedMovie.Director}
            </p>
            <p>
              <b>Genre:</b> {selectedMovie.Genre}
            </p>
            <p>
              <b>IMDb Rating:</b> ⭐ {selectedMovie.imdbRating}
            </p>
          </div>
        </div>
      )}

      {/* Recommendations */}
      {selectedMovie && recommendations.length > 0 && (
        <div>
          <h2>Recommended for You</h2>
          <div className="movies">
            {recommendations.map((movie) => (
              <div key={movie.imdbID} className="movie-card">
                <img
                  src={
                    movie.Poster !== "N/A"
                      ? movie.Poster
                      : "https://via.placeholder.com/300x450?text=No+Poster"
                  }
                  alt={movie.Title}
                  onClick={() => fetchMovieDetails(movie.imdbID)}
                />
                <h4>{movie.Title}</h4>
                <div className="card-actions">
                  <button onClick={() => toggleFavorite(movie)}>
                    {favorites.some((f) => f.imdbID === movie.imdbID)
                      ? "★"
                      : "☆"}
                  </button>
                  <button onClick={() => togglePlaylist(movie)}>▶</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Favorites Section */}
      {favorites.length > 0 && (
        <>
          <h2>Favorites</h2>
          <div className="movies">
            {favorites.map((movie) => (
              <div key={movie.imdbID} className="movie-card">
                <img
                  src={
                    movie.Poster !== "N/A"
                      ? movie.Poster
                      : "https://via.placeholder.com/300x450?text=No+Poster"
                  }
                  alt={movie.Title}
                  onClick={() => fetchMovieDetails(movie.imdbID)}
                />
                <h4>{movie.Title}</h4>
              </div>
            ))}
          </div>
        </>
      )}

      {/* Playlist Section */}
      {playlist.length > 0 && (
        <>
          <h2>My Playlist</h2>
          <div className="movies">
            {playlist.map((movie) => (
              <div key={movie.imdbID} className="movie-card">
                <img
                  src={
                    movie.Poster !== "N/A"
                      ? movie.Poster
                      : "https://via.placeholder.com/300x450?text=No+Poster"
                  }
                  alt={movie.Title}
                  onClick={() => fetchMovieDetails(movie.imdbID)}
                />
                <h4>{movie.Title}</h4>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default App;
