export const saveToLocal = (key, movie) => {
  const existing = JSON.parse(localStorage.getItem(key)) || [];
  if (!existing.find((m) => m.imdbID === movie.imdbID)) {
    existing.push(movie);
    localStorage.setItem(key, JSON.stringify(existing));
  }
};

export const loadFromLocal = (key) => {
  return JSON.parse(localStorage.getItem(key)) || [];
};
