import { useEffect, useState } from "react";
import MovieCard from "./MovieCard";

const API_KEY = "e167fd75";

function RecommendationRow({ title, query }) {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    fetch(`https://www.omdbapi.com/?apikey=${API_KEY}&s=${query}`)
      .then((res) => res.json())
      .then((data) => setMovies(data.Search || []));
  }, [query]);

  return (
    <>
      <h2>{title}</h2>
      <div className="movies">
        {movies.map((movie) => (
          <MovieCard key={movie.imdbID} movie={movie} />
        ))}
      </div>
    </>
  );
}

export default RecommendationRow;
