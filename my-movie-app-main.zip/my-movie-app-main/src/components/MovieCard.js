import "./MovieCard.css";

function MovieCard({ movie, onSelect, onFav, onPlay }) {
  return (
    <div className="movie-card">
      <img
  src={
    movie.Poster !== "N/A"
      ? movie.Poster
      : "https://via.placeholder.com/300x450/1f2937/ffffff?text=No+Poster"
  }
  alt={movie.Title}
  onClick={() => onSelect(movie.imdbID)}
/>

      <h4>{movie.Title}</h4>

      <div className="card-actions">
        {onFav && <button onClick={onFav}>❤️</button>}
        {onPlay && <button onClick={onPlay}>➕</button>}
      </div>
    </div>
  );
}

export default MovieCard;
